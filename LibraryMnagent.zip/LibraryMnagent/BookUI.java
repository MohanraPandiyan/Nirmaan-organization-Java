package LibraryMnagent;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class BookUI {
	public static void main(String[] args) {
		List<Book> ll = new LinkedList<Book>();
		Scanner sc = new Scanner(System.in);
		Book std = new Book();
		BookService service = new BookService();
		while(true) {
			System.out.println("Entr 1 for Add Book");
			System.out.println("Entr 2 for View Book");
			System.out.println("Entr 3 for Find Book ById");
			System.out.println("Entr 4 for update Book ById");
			System.out.println("Entr 5 for Remove Book ById");
			
			int num = sc.nextInt();
			switch(num) {
			case 1:
				ll.add(service.addbook());
			break;
			case 2:
				service.getbook(ll);
			break;
			case 3:
				Book existBook = service.getBookById(ll);
				if(existBook != null) {
					System.out.println(existBook);
				}else {
					System.out.println("Book Not Found");
				}
			break;
			case 4:
				ll = service.putBook(ll);
			break;
			case 5:
				ll = service.delBook(ll);
			break;
			default : 
				System.out.println("Enter the Correct Option");
			}
			
		}
	}

}
