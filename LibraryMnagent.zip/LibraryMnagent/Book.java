package LibraryMnagent;

public class Book {
	int BookId;
	String BookName;
	String BookAuthour;
	int BookPice;
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getBookAuthour() {
		return BookAuthour;
	}
	public void setBookAuthour(String BookAuthour) {
		this.BookAuthour = BookAuthour;
	}
	public int getBookPice() {
		return BookPice;
	}
	public void setBookPice(int bookPice) {
		BookPice = bookPice;
	}
	public Book(int bookId, String bookName, String bookAuthour, int bookPice) {
		super();
		this.BookId = bookId;
		this.BookAuthour = bookAuthour;
		this.BookPice = bookPice;
	}
	public Book() {
		super();
	}
	@Override
	public String toString() {
		return "Book [BookId=" + BookId + ", BookName=" + BookName + ", BookAuthour=" + BookAuthour + ", BookPice="
				+ BookPice + "]";
	}
	
	

}
