package LibraryMnagent;

import java.util.List;
import java.util.Scanner;

public class BookService {
	Scanner sc = new Scanner(System.in);
	public Book addbook() {
		System.out.println("Enter Book Id");
		int BookId = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Book Name");
		String BookName = sc.nextLine();
		System.out.println("Enter Book Authour");
		String BookAuhour = sc.nextLine();
		System.out.println("Enter Book Price");
		int BookPrice = sc.nextInt();
		return new Book(BookId,BookName,BookAuhour,BookPrice);
		
	}
	public void getbook(List<Book> info) {
		System.out.println(info);
	}
	public Book getBookById(List<Book> info) {
		System.out.println("Enter Book Id ");
		int bookId = sc.nextInt();
		for(Book book : info) {
			if (bookId == book.getBookId()) {
				return book;
			}
		}
		return null;
	}
	public List<Book> putBook(List<Book>info){
		System.out.println("Enter Book Id For Update : ");
		int id = sc.nextInt();
		sc.nextLine();
		for(Book book1 : info) {
			if(book1.getBookId()==id) {
				sc.nextLine();
				System.out.println("Enter Book Name");
				String BookName = sc.nextLine();
				System.out.println("Enter Book Authour");
				String BookAuhour = sc.nextLine();
				System.out.println("Enter Book Price");
				int BookPrice = sc.nextInt();
				book1.setBookName(BookName);
				book1.setBookAuthour(BookAuhour);
				book1.setBookPice(BookPrice);
				
			}
		}
		return info;
	}
	public List<Book>delBook(List<Book>info){
		System.out.println("Enter The Book Id For delete");
		int id = sc.nextInt();
		for(Book book3 : info) {
			if(id == book3.getBookId()) {
				info.remove(book3);
				return info;
			}
		}
		return info;
	}
}
