package student.management.system;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class UIStudent {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StudentService service = new StudentService();
		Set<Student> Ts = new HashSet<Student>();
		
		while(true) {
			System.out.println("Enter 1 For Add Student");
			System.out.println("Enter 2 For View Student");
			System.out.println("Enter 3 For Find Student");
			System.out.println("Enter 4 For Update Student");
			System.out.println("Enter 5 For Delete Student");
			int key = sc.nextInt();
			if(key==1) {
				 Student std = service.addStudent();
				System.out.println(std);
				Ts.add(std);
				System.out.println(Ts);
			}
			else if(key==2) {
				System.out.println(service.getStudent(Ts));
			}
			else if(key==3) {
				System.out.println(service.getStudentById(Ts));
			}
			else if(key==4) {
				service.putStudentById(Ts);
			}
			else if(key==5) {
				service.deleteStudentById(Ts);
			}
			else {
				System.out.println("No Student");
			}
		
		}
	}
	
}
