package student.management.system;

public class Student implements Comparable<Student> {
	int studentId;
	String studentName;
	String schoolName;
	int studenFees;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	public int getStudenFees() {
		return studenFees;
	}
	public void setStudenFees(int studenFees) {
		this.studenFees = studenFees;
	}
	public Student(int studentId, String studentName, String schoolName, int studenFees) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.schoolName = schoolName;
		this.studenFees = studenFees;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", schoolName=" + schoolName
				+ ", studenFees=" + studenFees + "]";
	}
	@Override
	public int compareTo(Student o) {
		if(this.studentId < o.getStudentId()) {
			return -1;
		}else if(this.studentId > o.getStudentId()) {
			return 1;
		} else {
		return 0;
		}
	}
	
	
}
