package student.management.system;

import java.util.Scanner;
import java.util.Set;

public class StudentService implements IStudentService {
	Scanner sc = new Scanner(System.in);

	@Override
	public Student addStudent() {
		System.out.println("Enter Student Id");
		int Id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Student Name");
		String Name = sc.nextLine();
		System.out.println("Enter School Name");
		String SName = sc.nextLine();
		System.out.println("Enter The fees");
		int Fee = sc.nextInt();
		
		Student std = new Student(Id, Name, SName, Fee);
		return std;
		
	}

	@Override
	public Set<Student> getStudent(Set<Student> Set) {
		return Set;
		
	}

	@Override
	public Student getStudentById(Set<Student> Set) {
		System.out.println("Enter Student Id");
		int StdId = sc.nextInt();
		for(Student Std : Set) {
			if(StdId==Std.studentId) {
				return Std;
			}
		}
		return null;
		
	}

	@Override
	public Set<Student> putStudentById(Set<Student> Set) {
		System.out.println("Enter Student Id");
		int StdId = sc.nextInt();
		for(Student Std : Set) {
			if(StdId==Std.studentId) {
				System.out.println("Enter Student Name");
				String Name = sc.nextLine();
				System.out.println("Enter School Name");
				String SName = sc.nextLine();
				System.out.println("Enter The fees");
				int Fee = sc.nextInt();
				Std.setStudentName(Name);
				Std.setSchoolName(SName);
				Std.setStudenFees(Fee);
				
			}
		}
		return null;
	}

	@Override
	public Set<Student> deleteStudentById(Set<Student> Set) {
		System.out.println("Enter Student Id");
		int StdId = sc.nextInt();
		for(Student Std : Set) {
			if(StdId==Std.studentId) {
				Set.remove(Std);
				return Set;
			}
		}
		return null;
	}

	
	

	

}
