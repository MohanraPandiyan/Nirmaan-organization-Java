package student.management.system;

import java.util.Set;

public interface IStudentService {
	public Student addStudent();
	public Set<Student> getStudent(Set<Student> Set);
	public Student getStudentById(Set<Student>Set);
	public Set<Student>putStudentById(Set<Student>Set);
	public Set<Student>deleteStudentById(Set<Student>Set);
	
}
